# Voxora AI

Open `index.html` in a modern browser to use the application.

## GitHub Pages
Upload the HTML file to the repository root and name it exactly `index.html` (not README.md). Then select Settings → Pages → Deploy from a branch → `main` → `/(root)`.

## Notes
- Core lessons, practice prompts and local reports are free.
- AI-generated feedback/chat requires optional local Ollama setup.
- Microphone and speech recognition depend on browser permissions and support.
- The level estimate is indicative only, not an official CEFR test.
